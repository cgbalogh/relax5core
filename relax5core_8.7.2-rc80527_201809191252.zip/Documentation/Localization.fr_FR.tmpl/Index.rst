﻿.. ==================================================
.. FOR YOUR INFORMATION
.. --------------------------------------------------
.. -*- coding: utf-8 -*- with BOM.

.. include:: ../Includes.txt


.. _start:

=============================================================
relax5core (Français)
=============================================================

.. only:: html

	:Classification:
		extension_key

	:Version:
		|release|

	:Langue:
		fr

	:Description:
		entrez une description.

	:Mots-clés:
		list,mots-clés,séparés,par,virgules

	:Copyright:
		2017

	:Auteur:
		Christoph Balogh

	:E-mail:
		author@example.com

	:Licence:
		Ce document est publié sous la licence de contenu libre
		disponible sur http://www.opencontent.org/opl.shtml

	:Généré:
		|today|

	Le contenu de ce document est en relation avec TYPO3,
	un CMS/Framework GNU/GPL disponible sur `www.typo3.org <https://typo3.org/>`__.


	**Sommaire**

.. toctree::
	:maxdepth: 3
	:titlesonly:

..	Introduction/Index
..	UsersManual/Index
..	AdministratorManual/Index
