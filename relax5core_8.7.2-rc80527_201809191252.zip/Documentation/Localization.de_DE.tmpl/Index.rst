﻿.. ==================================================
.. FOR YOUR INFORMATION
.. --------------------------------------------------
.. -*- coding: utf-8 -*- with BOM.

.. include:: ../Includes.txt


.. _start:

=============================================================
relax5core (Deutsch)
=============================================================

.. only:: html

	:Klassifikation:
		extension_key

	:Version:
		|release|

	:Sprache:
		de

	:Beschreibung:
		Geben Sie eine Beschreibung ein.

	:Schlüsselwörter:
		komma-getrennte,Liste,von,Schlüsselwörtern

	:Copyright:
		2017

	:Autor:
		Christoph Balogh

	:E-Mail:
		author@example.com

	:Lizenz:
		Dieses Dokument wird unter der Open Content License, siehe
		http://www.opencontent.org/opl.shtml veröffentlicht.

	:Gerendert:
		|today|

	Der Inhalt dieses Dokuments bezieht sich auf TYPO3,
	ein GNU/GPL CMS-Framework auf `www.typo3.org <https://typo3.org/>`__.


	**Inhaltsverzeichnis**

.. toctree::
	:maxdepth: 3
	:titlesonly:

..	Introduction/Index
..	UsersManual/Index
..	AdministratorManual/Index
