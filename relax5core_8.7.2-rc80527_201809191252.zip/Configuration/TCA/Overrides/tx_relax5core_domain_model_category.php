<?php
$GLOBALS['TCA']['tx_relax5core_domain_model_category']['ctrl']['sortby'] = 'category';
